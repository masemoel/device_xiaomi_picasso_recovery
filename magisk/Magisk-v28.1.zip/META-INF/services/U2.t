Q2.a
